/*
 * ush.h
 *
 *  Created on: 03-Oct-2013
 *      Author: sriraam
 */

#ifndef USH_H_
#define USH_H_

int execute(Pipe pipe);

#endif /* USH_H_ */
