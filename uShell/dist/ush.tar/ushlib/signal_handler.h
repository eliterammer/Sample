/*
 * signal_handler.h
 *
 *  Created on: 16-Oct-2013
 *      Author: sriraam
 */

#ifndef SIGNAL_HANDLER_H_
#define SIGNAL_HANDLER_H_
#include<signal.h>
void handleSignals();


#endif /* SIGNAL_HANDLER_H_ */
