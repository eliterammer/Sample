/*
 * ushio.h
 *
 *  Created on: 11-Oct-2013
 *      Author: sriraam
 */

#ifndef USHIO_H_
#define USHIO_H_

static const char const* TMPIFILE = ".tmpIFileUsh";
static const char const* TMPOFILE = ".tmpOFileUsh";


void closeIO(Cmd c);
void setIO(Cmd c);

#endif /* USHIO_H_ */
